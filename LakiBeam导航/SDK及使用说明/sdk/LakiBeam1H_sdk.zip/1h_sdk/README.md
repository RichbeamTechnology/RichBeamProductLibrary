# Compile

```
mkdir build
```

```
cmake -S . -B build -G "MinGW Makefiles"
```

```
cmake --build build -- -j
```

# Run Examples

```
./build/bin/cpp_minimal.exe
```
or
```
./build/bin/c_minimal.exe
```

