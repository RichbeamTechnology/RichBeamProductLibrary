#include "rb_lidar.hpp"
#include <iostream>
#include <vector>

int main() {
    rblidar::Config cfg;
    cfg.ip   = "0.0.0.0";
    cfg.port = 2368;

    rblidar::Lidar lidar(cfg);
    lidar.setCallback([](const std::vector<rblidar::PointData>& frame){
        std::cout << "[frame] points=" << frame.size() << "\n";

        for (size_t i = 0; i < frame.size(); ++i) {
            const auto& p = frame[i];
            std::cout << "  [" << i << "] "
                      << "az=" << p.azimuth
                      << " dist=" << p.dist
                      << " rssi=" << p.rssi
                      << " ts=" << p.timestamp
                      << "\n";
        }

        std::cout << std::flush;
    });

    lidar.start();

    std::cout << "Press Enter to quit...\n";
    std::cin.get();

    lidar.stop();
    return 0;
}
