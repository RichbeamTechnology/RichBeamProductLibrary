import ctypes, os, sys
from ctypes import (c_uint16, c_uint32, c_int, c_char_p, c_void_p,
                    POINTER, Structure)

if sys.platform.startswith("win"):
    lib = ctypes.CDLL("../build/bin/librblidar.dll")
else:
    lib = ctypes.CDLL(os.path.join("..","build","lib","librblidar.so"))


# ==== 2) C 结构定义（和 rb_lidar_c.h 对齐）====
class RBLidarPoint(Structure):
    _fields_ = [
        ("azimuth",   c_uint16),
        ("dist",      c_uint16),
        ("rssi",      c_uint16),
        ("timestamp", c_uint32),
    ]

class RBLidarCfg(Structure):
    _fields_ = [
        ("ip",            c_char_p),   # const char*
        ("port",          c_uint16),
        ("drop_overflow", c_int),
        ("subpkt_buffer", c_uint32),
    ]

# ==== 3) 函数原型（一定要设，否则 ctypes 会默认 int 并搞崩溃）====
CBTYPE = ctypes.CFUNCTYPE(None, POINTER(RBLidarPoint), c_int, c_void_p)

lib.rblidar_create.argtypes  = [ctypes.POINTER(RBLidarCfg)]
lib.rblidar_create.restype   = c_void_p
lib.rblidar_destroy.argtypes = [c_void_p]
lib.rblidar_destroy.restype  = None
lib.rblidar_start.argtypes   = [c_void_p]
lib.rblidar_start.restype    = None
lib.rblidar_stop.argtypes    = [c_void_p]
lib.rblidar_stop.restype     = None
lib.rblidar_set_callback.argtypes = [c_void_p, CBTYPE, c_void_p]
lib.rblidar_set_callback.restype  = None

# ==== 4) 回调函数（保持强引用，防 GC）====
def on_frame(data_ptr, length, user):
    try:
        print("frame:", length)
        if length > 0:
            p = data_ptr[0]
            print("  first: az=%u dist=%u rssi=%u ts=%u" %
                  (p.azimuth, p.dist, p.rssi, p.timestamp))
    except Exception as e:
        # 任何异常都别抛回 C 层，打印即可
        print("callback error:", e, file=sys.stderr)

CB_KEEPALIVE = CBTYPE(on_frame)        # <<< 关键：保留全局引用
USER_PTR = None

# ==== 5) 创建、设置回调、启动 ====
cfg = RBLidarCfg(b"0.0.0.0", 2368, 1, 512)
h = lib.rblidar_create(ctypes.byref(cfg))
if not h:
    raise RuntimeError("rblidar_create failed")

lib.rblidar_set_callback(h, CB_KEEPALIVE, USER_PTR)
lib.rblidar_start(h)

input("Press Enter to quit...")

lib.rblidar_stop(h)
lib.rblidar_destroy(h)