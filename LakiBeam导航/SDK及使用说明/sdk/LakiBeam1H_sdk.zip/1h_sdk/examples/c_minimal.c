#include "rb_lidar_c.h"
#include <stdio.h>

static void my_cb(const rblidar_point_t* data, int length, void* user) {
    (void)user;
    printf("[frame] n=%d\n", length);

    for (int i = 0; i < length; ++i) {
        printf("  [%d] az=%u dist=%u rssi=%u ts=%u\n",
               i,
               (unsigned)data[i].azimuth,
               (unsigned)data[i].dist,
               (unsigned)data[i].rssi,
               (unsigned)data[i].timestamp);
    }
    fflush(stdout);
}

int main() {
    rblidar_config_t cfg = { "0.0.0.0", 2368, 1, 512 };

    RBLidarHandle* h = rblidar_create(&cfg);
    if (!h) {
        fprintf(stderr, "rblidar_create failed\n");
        return 1;
    }

    rblidar_set_callback(h, &my_cb, NULL);

    /* 注意：rblidar_start 返回 void，不能写 if (rblidar_start(...) != 0) */
    rblidar_start(h);

    puts("Press Enter to quit...");
    getchar();

    rblidar_stop(h);
    rblidar_destroy(h);
    return 0;
}
