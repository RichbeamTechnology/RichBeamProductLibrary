#pragma once
#include <stdint.h>
#include "rb_lidar_export.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct RBLidarHandle RBLidarHandle;

typedef struct {
    const char* ip;         // e.g. "0.0.0.0"
    uint16_t    port;       // e.g. 2368
    int         drop_overflow; // 1/0
    uint32_t    subpkt_buffer; // e.g. 512
} rblidar_config_t;

typedef struct {
    uint16_t azimuth;
    uint16_t dist;
    uint16_t rssi;
    uint32_t timestamp;
} rblidar_point_t;

// 回调：一帧点云（vector 语义），data 指向 rblidar_point_t 数组，length 是元素个数
typedef void (*rblidar_frame_cb)(const rblidar_point_t* data, int length, void* user);

RBLIDAR_API RBLidarHandle* rblidar_create(const rblidar_config_t* cfg);
RBLIDAR_API void           rblidar_destroy(RBLidarHandle* h);
RBLIDAR_API void           rblidar_start(RBLidarHandle* h);
RBLIDAR_API void           rblidar_stop(RBLidarHandle* h);
RBLIDAR_API void           rblidar_set_callback(RBLidarHandle* h, rblidar_frame_cb cb, void* user);

#ifdef __cplusplus
}
#endif
