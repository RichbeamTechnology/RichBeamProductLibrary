#pragma once
#include "rb_lidar_export.h"
#include "rb_lidar_wire.hpp"
#include <cstdint>
#include <functional>
#include <mutex>
#include <condition_variable>
#include <string>
#include <thread>
#include <vector>
#include <atomic>

namespace rblidar {

struct PointData {
    uint16_t azimuth;    // 0.01°
    uint16_t dist;       // 与原逻辑一致：= raw * 2
    uint16_t rssi;
    uint32_t timestamp;  // 插值后的每点时间戳
};

struct Config {
    std::string ip     = "0.0.0.0"; // 绑定的本地IP
    uint16_t    port   = 2368;      // 监听端口
    bool        drop_overflow = true; // 子包缓冲溢出策略
    size_t      subpkt_buffer = 512;  // 双缓冲每半侧容量
};

using FrameCallback = std::function<void(const std::vector<PointData>&)>;

class RBLIDAR_API Lidar {
public:
    explicit Lidar(const Config& cfg);
    ~Lidar();

    // 不可拷贝，可移动
    Lidar(const Lidar&) = delete;
    Lidar& operator=(const Lidar&) = delete;
    Lidar(Lidar&&) = delete;
    Lidar& operator=(Lidar&&) = delete;

    // 设置 C++ 回调（线程安全）
    void setCallback(FrameCallback cb);

    // 启停
    void start();
    void stop();

private:
    // 内部结构
    struct SubBuf {
        std::vector<SubPacket>  pkts;
        std::vector<uint32_t>   ts;
        size_t valid = 0;
        void reset(size_t cap) { pkts.assign(cap, {}); ts.assign(cap, 0); valid = 0; }
    };

    void rxLoop();        // UDP接收线程
    void assembleLoop();  // 组包线程

    Config cfg_;
    FrameCallback cb_;

    // 双缓冲
    SubBuf buf_[2];
    int cur_ = 0;

    std::mutex mtx_;
    std::condition_variable cv_;

    std::thread th_rx_;
    std::thread th_asm_;
    std::atomic<bool> running_{false};

    // 辅助状态
    uint16_t last_azimuth_ = 0xFFFF;
};

} // namespace rblidar
