#pragma once

#if defined(_WIN32) || defined(_WIN64)
  #if defined(RB_LIDAR_BUILD)
    #define RBLIDAR_API __declspec(dllexport)
  #else
    #define RBLIDAR_API __declspec(dllimport)
  #endif
#else
  #define RBLIDAR_API __attribute__((visibility("default")))
#endif
