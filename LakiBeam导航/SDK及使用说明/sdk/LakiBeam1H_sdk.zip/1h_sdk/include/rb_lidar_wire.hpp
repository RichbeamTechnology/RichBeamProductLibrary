#pragma once
#include <cstdint>

#ifndef CONFIG_BLOCK_COUNT
#define CONFIG_BLOCK_COUNT   16
#endif
#ifndef CONFIG_UDP_BLOCKS
#define CONFIG_UDP_BLOCKS    12
#endif
#ifndef UDP_BUF_SIZE
#define UDP_BUF_SIZE         1206
#endif

static constexpr uint16_t RBLIDAR_BLOCK_HEADER = 0xEEFF;

#pragma pack(push, 1)
struct RawPoint {
    uint16_t dist_0;
    uint8_t  rssi_0;
    uint16_t dist_1;
    uint8_t  rssi_1;
};

struct SubPacket {
    uint16_t header;    // 0xFFFF 表示空
    uint16_t azimuth;   // 0.01°
    RawPoint point[CONFIG_BLOCK_COUNT];
};

struct UdpPacket {
    SubPacket sub_packet[CONFIG_UDP_BLOCKS];
    uint32_t  timestamp;     // 固件定义
    uint16_t  factory_byte;  // 固件定义
};
#pragma pack(pop)

static_assert(sizeof(SubPacket) * CONFIG_UDP_BLOCKS + 4 + 2 == UDP_BUF_SIZE,
              "Wire size mismatch: check CONFIG_* and UDP_BUF_SIZE");
