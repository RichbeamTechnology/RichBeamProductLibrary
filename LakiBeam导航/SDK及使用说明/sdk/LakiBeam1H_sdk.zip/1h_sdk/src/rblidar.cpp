#define RB_LIDAR_BUILD
#include "rb_lidar.hpp"
#include "net_udp.hpp"
#include <cstring>
#include <iostream>

namespace rblidar
{

	Lidar::Lidar(const Config &cfg) : cfg_(cfg)
	{
		buf_[0].reset(cfg_.subpkt_buffer);
		buf_[1].reset(cfg_.subpkt_buffer);
	}

	Lidar::~Lidar() { stop(); }

	void Lidar::setCallback(FrameCallback cb)
	{
		std::lock_guard<std::mutex> lk(mtx_);
		cb_ = std::move(cb);
	}

	void Lidar::start()
	{
		bool expected = false;
		if (!running_.compare_exchange_strong(expected, true))
			return;

		th_rx_ = std::thread(&Lidar::rxLoop, this);
		th_asm_ = std::thread(&Lidar::assembleLoop, this);
	}

	void Lidar::stop()
	{
		bool expected = true;
		if (!running_.compare_exchange_strong(expected, false))
			return;

		{
			std::lock_guard<std::mutex> lk(mtx_);
			cv_.notify_all();
		}
		if (th_rx_.joinable())
			th_rx_.join();
		if (th_asm_.joinable())
			th_asm_.join();
	}

	void Lidar::rxLoop()
	{
		UdpSocket sock;
		if (!sock.bind(cfg_.ip, cfg_.port))
		{
			std::cerr << "[rb_lidar] bind failed on " << cfg_.ip << ":" << cfg_.port << "\n";
			running_ = false;
			return;
		}
		std::cout << "[rb_lidar] listening " << cfg_.ip << ":" << cfg_.port << " ...\n";

		UdpPacket pkt{};
		uint32_t timestamp_last = 0;
		uint32_t timestamp_div = 1;

#ifdef RB_LIDAR_DEBUG
		uint64_t total_pkts = 0;
		uint64_t total_subp = 0;
#endif

		while (running_)
		{
			alignas(8) unsigned char rxbuf[4096];
			int n = sock.recv(rxbuf, sizeof(rxbuf));
			if (n <= 0)
			{
#ifdef RB_LIDAR_DEBUG
				std::cerr << "[rb_lidar] recv err/timeout, n=" << n << "\n";
#ifdef _WIN32
				int e = sock.last_error();
				if (e == WSAETIMEDOUT)
				{
					std::cerr << "[rb_lidar] recv timeout (10060)\n";
				}
				else if (e == WSAECONNRESET)
				{
					std::cerr << "[rb_lidar] WSAECONNRESET (10054) — UDP connreset\n";
				}
				else if (e == WSAEMSGSIZE)
				{
					std::cerr << "[rb_lidar] WSAEMSGSIZE (10040) — datagram larger than buffer\n";
				}
				else if (e == WSAEWOULDBLOCK)
				{
					std::cerr << "[rb_lidar] WSAEWOULDBLOCK (10035)\n";
				}
				else
				{
					std::cerr << "[rb_lidar] recv error code=" << e << "\n";
				}
#else
				std::cerr << "[rb_lidar] recv error errno=" << sock.last_error() << "\n";
#endif

#endif
				continue;
			}
			if (n < (int)sizeof(pkt))
			{
#ifdef RB_LIDAR_DEBUG
				std::cerr << "[rb_lidar] short packet: " << n
						  << " bytes, expect " << sizeof(pkt) << "\n";
#endif
				continue; // 若你的协议与此不同，请调整 rb_lidar_wire.hpp 与 UDP_BUF_SIZE
			}

#ifdef RB_LIDAR_DEBUG
			++total_pkts;
			if ((total_pkts % 100) == 0)
			{
				std::cout << "[rb_lidar] udp ok, pkt=" << total_pkts
						  << " size=" << n
						  << " first.az=" << pkt.sub_packet[0].azimuth
						  << " hdr0=0x" << std::hex << pkt.sub_packet[0].header << std::dec
						  << " ts=" << pkt.timestamp << "\n";
			}
#endif

			std::memcpy(&pkt, rxbuf, sizeof(UdpPacket));

			std::unique_lock<std::mutex> lk(mtx_);

			uint32_t tcur = pkt.timestamp;
			if (tcur == 0)
			{
				tcur = timestamp_last;
			}
			else
			{
				timestamp_div = (tcur - timestamp_last) / CONFIG_UDP_BLOCKS;
				timestamp_last = tcur;
			}

			auto &curbuf = buf_[cur_];

			for (int i = 0; i < CONFIG_UDP_BLOCKS; ++i)
			{
				const SubPacket &sp = pkt.sub_packet[i];

				// 1) 校验子包头（0xEEFF），不合法就丢
				if (sp.header != RBLIDAR_BLOCK_HEADER)
				{
#ifdef RB_LIDAR_DEBUG
					std::cerr << "[rb_lidar] bad header: 0x"
							  << std::hex << sp.header << std::dec
							  << " (expect 0x" << std::hex << RBLIDAR_BLOCK_HEADER << std::dec << ")\n";
#endif
					continue;
				}

				// 2) —— 先判断是否“跨帧”（回绕或接近 0°）——
				const uint16_t az = sp.azimuth;
				const uint16_t last = last_azimuth_;
				const bool wrapped = (az < last);
				const bool nearZero = (az <= 50); // ≤0.5° 视为跨零

				if (wrapped || nearZero)
				{
					// 把“上一侧缓冲”(旧 cur_) 交给组包线程；然后切到新侧，从0开始写
					const int prev = cur_;
#ifdef RB_LIDAR_DEBUG
					std::cout << "[rb_lidar] SWITCH: last=" << last << " -> az=" << az
							  << " (wrapped=" << wrapped << ", nearZero=" << nearZero << ") "
							  << " prev.valid=" << buf_[prev].valid << "\n";
#endif
					if (buf_[prev].valid > 0)
					{
						// 唤醒 assembleLoop：它会读 buf_[(cur_+1)&1]，即我们切换后的“上一侧”
						cur_ = (cur_ + 1) & 1;
						buf_[cur_].valid = 0; // 新侧清零
						cv_.notify_one();
					}
					else
					{
						// 上一侧没有有效数据也切换，但不通知
						cur_ = (cur_ + 1) & 1;
						buf_[cur_].valid = 0;
					}
				}
				last_azimuth_ = az;

				// 3) —— 现在 current 已经是正确的“本圈缓冲”，再写当前子包 —— //
				auto &curbuf = buf_[cur_];

				if (curbuf.valid >= curbuf.pkts.size())
				{
#ifdef RB_LIDAR_DEBUG
					std::cerr << "[rb_lidar] overflow at " << curbuf.valid
							  << " (cap=" << curbuf.pkts.size() << ")\n";
#endif
					if (cfg_.drop_overflow)
					{
						// 丢掉本 UDP 后续子包
						break;
					}
					else
					{
						// 强制切帧：把已积累的交出去，然后新侧从0开始再写当前子包
						const int prev = cur_;
						cur_ = (cur_ + 1) & 1;
						buf_[cur_].valid = 0;
						cv_.notify_one();
						// 切完别忘了刷新引用
						curbuf = buf_[cur_];
					}
				}

				// 写入当前子包到“当前帧”的缓冲
				curbuf.pkts[curbuf.valid] = sp;
				curbuf.ts[curbuf.valid] = tcur + i * timestamp_div;
				++curbuf.valid;

#ifdef RB_LIDAR_DEBUG
				static uint64_t dbg_cnt = 0;
				++dbg_cnt;
				if ((dbg_cnt & 0x7F) == 0)
				{
					std::cout << "[rb_lidar] subp#" << dbg_cnt
							  << " cur=" << cur_ << " valid=" << curbuf.valid
							  << " az=" << az << "\n";
				}
#endif
			}
		}
	}

	void Lidar::assembleLoop()
	{
		while (running_)
		{
			std::unique_lock<std::mutex> lk(mtx_);
			cv_.wait(lk, [this]
					 { return !running_ || buf_[(cur_ + 1) & 1].valid > 1; });
			if (!running_)
				break;

			const int next = (cur_ + 1) & 1;
			const auto count = buf_[next].valid;

#ifdef RB_LIDAR_DEBUG
			std::cout << "[rb_lidar] assemble: next=" << next
					  << " subpkt.count=" << count << "\n";
#endif

			std::vector<PointData> frame;
			frame.reserve(count * CONFIG_BLOCK_COUNT * 2);

			for (size_t i = 0; i + 1 < count; ++i)
			{
				const auto &sp = buf_[next].pkts[i];
				const auto &spn = buf_[next].pkts[i + 1];

				int start_angle = sp.azimuth % 36000;
				int end_angle = spn.azimuth % 36000;
				int div_angle = (end_angle >= start_angle)
									? (end_angle - start_angle) / CONFIG_BLOCK_COUNT
									: ((36000 - start_angle + end_angle) / CONFIG_BLOCK_COUNT);

				uint32_t t0 = buf_[next].ts[i];
				uint32_t t1 = buf_[next].ts[i + 1];
				uint32_t dt = (t1 - t0) / CONFIG_BLOCK_COUNT;

				for (int j = 0; j < CONFIG_BLOCK_COUNT; ++j)
				{
					PointData p1;
					p1.azimuth = (start_angle + j * div_angle) % 36000;
					p1.dist = static_cast<uint16_t>(sp.point[j].dist_0 * 2);
					p1.rssi = sp.point[j].rssi_0;
					p1.timestamp = t0 + j * dt;
					frame.push_back(p1);

					PointData p2;
					p2.azimuth = (start_angle + j * div_angle + div_angle / 2) % 36000;
					p2.dist = static_cast<uint16_t>(sp.point[j].dist_1 * 2);
					p2.rssi = sp.point[j].rssi_1;
					p2.timestamp = t0 + j * dt + dt / 2;
					frame.push_back(p2);
				}
			}

			// 清空 next 缓冲
			buf_[next].valid = 0;
			lk.unlock();

#ifdef RB_LIDAR_DEBUG
			std::cout << "[rb_lidar] frame points=" << frame.size() << "\n";
			if (!frame.empty())
			{
				const auto &p = frame.front();
				std::cout << "  first: az=" << p.azimuth
						  << " dist=" << p.dist
						  << " rssi=" << p.rssi
						  << " ts=" << p.timestamp << "\n";
			}
#endif

			// 回调（不持锁）
			FrameCallback cb;
			{
				std::lock_guard<std::mutex> lk2(mtx_);
				cb = cb_;
			}
			if (cb)
				cb(frame);
		}
	}

} // namespace rblidar
