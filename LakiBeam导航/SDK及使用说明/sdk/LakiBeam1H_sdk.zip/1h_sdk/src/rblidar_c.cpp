#define RB_LIDAR_BUILD
#include "rb_lidar_c.h"
#include "rb_lidar.hpp"
#include <memory>
#include <vector>

using rblidar::Lidar;

struct RBLidarHandle
{
    std::unique_ptr<Lidar> ptr;
    // 为了把 C++ vector 转成 C 回调的临时缓存：
    std::vector<rblidar_point_t> scratch;
    rblidar_frame_cb cb = nullptr;
    void *user = nullptr;
};

static rblidar::Config toCfg(const rblidar_config_t *c)
{
    rblidar::Config cfg;
    if (c && c->ip)
        cfg.ip = c->ip;
    if (c)
    {
        cfg.port = c->port ? c->port : 2368;
        cfg.drop_overflow = (c->drop_overflow != 0);
        cfg.subpkt_buffer = c->subpkt_buffer ? c->subpkt_buffer : 512;
    }
    return cfg;
}

extern "C"
{

    RBLidarHandle *rblidar_create(const rblidar_config_t *cfg)
    {
        auto h = new RBLidarHandle;
        h->ptr = std::make_unique<Lidar>(toCfg(cfg));
        // 连接 C++ → C 回调桥
        h->ptr->setCallback([h](const std::vector<rblidar::PointData> &v)
                            {
        if (!h->cb) return;
        h->scratch.resize(v.size());
        for (size_t i=0;i<v.size();++i) {
            h->scratch[i].azimuth   = v[i].azimuth;
            h->scratch[i].dist      = v[i].dist;
            h->scratch[i].rssi      = v[i].rssi;
            h->scratch[i].timestamp = v[i].timestamp;
        }
        h->cb(h->scratch.data(), (int)h->scratch.size(), h->user); });
        return h;
    }

    void rblidar_destroy(RBLidarHandle *h)
    {
        if (!h)
            return;
        h->ptr.reset();
        delete h;
    }

    void rblidar_start(RBLidarHandle *h)
    {
        if (h)
            h->ptr->start();
    }
    void rblidar_stop(RBLidarHandle *h)
    {
        if (h)
            h->ptr->stop();
    }

    void rblidar_set_callback(RBLidarHandle *h, rblidar_frame_cb cb, void *user)
    {
        if (!h)
            return;
        h->cb = cb;
        h->user = user;
    }

} // extern "C"
