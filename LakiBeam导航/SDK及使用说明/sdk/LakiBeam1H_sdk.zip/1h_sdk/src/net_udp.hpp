#pragma once
#include <string>
#include <cstdint>
#include <cstring>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#ifndef SIO_UDP_CONNRESET
#define SIO_UDP_CONNRESET _WSAIOW(IOC_VENDOR, 12)
#endif
#pragma comment(lib, "Ws2_32.lib")
#else
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#endif

class UdpSocket
{
public:
    UdpSocket() {}
    ~UdpSocket() { close(); }

    bool bind(const std::string &ip, uint16_t port)
    {
#ifdef _WIN32
        WSADATA wsa;
        WSAStartup(MAKEWORD(2, 2), &wsa);
#endif
        sock_ =
#ifdef _WIN32
            ::socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
#else
            ::socket(AF_INET, SOCK_DGRAM, 0);
#endif
        if (sock_ < 0
#ifdef _WIN32
            || sock_ == INVALID_SOCKET
#endif
        )
            return false;

        int yes = 1;
#ifdef _WIN32
        ::setsockopt(sock_, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(yes));
#else
        ::setsockopt(sock_, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
#endif

        // 1s 接收超时
        int to_ms = 1000;
        ::setsockopt(sock_, SOL_SOCKET, SO_RCVTIMEO, (const char *)&to_ms, sizeof(to_ms));

        // 放大接收缓冲
        int rcvbuf = 1 * 1024 * 1024;
        ::setsockopt(sock_, SOL_SOCKET, SO_RCVBUF, (const char *)&rcvbuf, sizeof(rcvbuf));

#ifdef _WIN32
        // 忽略 UDP connreset (10054)
        DWORD bytes = 0;
        BOOL newBehavior = FALSE;
        WSAIoctl(sock_, SIO_UDP_CONNRESET, &newBehavior, sizeof(newBehavior),
                 NULL, 0, &bytes, NULL, NULL);
#endif

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        inet_pton(AF_INET, ip.c_str(), &addr.sin_addr);

        if (::bind(sock_, (sockaddr *)&addr, sizeof(addr)) < 0)
        {
            close();
            return false;
        }
        return true;
    }

    // 返回读取的字节数；错误/超时返回 -1，并记录 last_err_
    int recv(void *buf, int len)
    {
#ifdef _WIN32
        // 直接用 recv，避免 from/fromlen 组合导致的 10014
        int n = ::recv(sock_, (char *)buf, len, 0);
        last_err_ = (n < 0) ? WSAGetLastError() : 0;
        return n;
#else
        // POSIX 下也可以用 recv，无需源地址
        int n = ::recv(sock_, buf, len, 0);
        last_err_ = (n < 0) ? errno : 0;
        return n;
#endif
    }

    int last_error() const { return last_err_; }

    void close()
    {
#ifdef _WIN32
        if (sock_ != INVALID_SOCKET)
        {
            closesocket(sock_);
            WSACleanup();
            sock_ = INVALID_SOCKET;
        }
#else
        if (sock_ >= 0)
        {
            ::close(sock_);
            sock_ = -1;
        }
#endif
    }

private:
#ifdef _WIN32
    SOCKET sock_ = INVALID_SOCKET;
#else
    int sock_ = -1;
#endif
    int last_err_ = 0;
};
