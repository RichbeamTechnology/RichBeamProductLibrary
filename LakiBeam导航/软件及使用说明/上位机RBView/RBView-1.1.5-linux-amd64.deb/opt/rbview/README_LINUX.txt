RBView Linux amd64 package.

Run:
  ./rbview

The package bundles RBView runtime libraries under lib/ and Qt plugins under
plugins/. It intentionally does not bundle the system OpenGL/Mesa/DRI driver
stack or the system C++ runtime, because those libraries must match the target
Ubuntu installation and GPU driver.

This package is built on Ubuntu 20.04 to keep the glibc runtime baseline
compatible with Ubuntu 20.04, 22.04, 24.04 and newer distributions. It does
not bundle glibc; the target system must provide libc6 >= 2.31.

For tar package installs, make sure the target system has the OpenGL runtime:
  sudo apt install libgl1 libglx0 libgl1-mesa-dri libegl1 libstdc++6 libgcc-s1
